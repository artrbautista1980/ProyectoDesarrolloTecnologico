import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { IgxAvatarModule } from 'igniteui-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LoginComponent } from './pages/login/login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { HeaderComponent } from './shared/header/header.component';
import { EmpresasComponent } from './pages/empresas/empresas/empresas.component';
import { RouterModule } from '@angular/router';
import { MarcasComponent } from './pages/marcas/marcas.component';
import { EstatusComponent } from './pages/estatus/estatus.component';
import { ModelosComponent } from './pages/modelos/modelos.component';
import { ProveedoresComponent } from './pages/proveedores/proveedores.component';
import { SoftwareComponent } from './pages/software/software.component';
import { TiposEquiposComponent } from './pages/tipos-equipos/tipos-equipos.component';
import { UbicacionesComponent } from './pages/ubicaciones/ubicaciones.component';
import { EmpleadosComponent } from './pages/empleados/empleados.component';
import { InventariosComponent } from './pages/inventarios/inventarios.component';
import { BitacoraComponent } from './pages/bitacora/bitacora.component';
import { FacturasComponent } from './pages/facturas/facturas.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    EmpresasComponent,
    MarcasComponent,
    EstatusComponent,
    ModelosComponent,
    ProveedoresComponent,
    SoftwareComponent,
    TiposEquiposComponent,
    UbicacionesComponent,
    EmpleadosComponent,
    InventariosComponent,
    BitacoraComponent,
    FacturasComponent
    ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    IgxAvatarModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule {
}
