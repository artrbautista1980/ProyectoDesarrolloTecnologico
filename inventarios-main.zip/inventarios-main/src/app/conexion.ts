export const conexion = {
        //URL Desarrollo
   // url: 'i-cat-imx.website/api_inventarios/api/',
    url: 'https://i-cat-imx.website/api_inventarios/api/',
    licencia:'j7D8aOcFrG6TP2ebF59ZPLwQX7Bq3ytqCAs3SMKoku8AHo6zdLv4yU9pNrnxQ2Kmh1WlVfHw11DYGSJMEt964705ei2ig5R83JI4'
    }
    