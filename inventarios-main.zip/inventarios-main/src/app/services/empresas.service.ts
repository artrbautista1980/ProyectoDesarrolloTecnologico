import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpresasService {
  private apiUrl = conexion.url;
    // 🔐 Headers personalizados con Licencia
    private headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Licencia': conexion.licencia
    });
  
    // Opciones reutilizables
    private options = {
      headers: this.headers
    };

  constructor(
  private http: HttpClient
    ) { }

  getEmpresa(id_empresa : any){
    
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',   
        'Licencia': conexion.licencia     
     });
    let options = { headers: headers };
    const data = {}
    let url=conexion.url+"empresas/"+id_empresa;
    
    return this.http.get(url,options);
  }

/*   getEmpresas(){
    
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',   
        'Licencia': conexion.licencia     
     });
    let options = { headers: headers };
    const data = {}
    let url=conexion.url+"cards/"+id_empresa;
    
    return this.http.get(url,options);
  } */
  getEmpresas(): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',   
      'Licencia': conexion.licencia     
   });
    let options = { headers: headers };
    return this.http.get(this.apiUrl+'empresas',options);
  }
  crearEmpresa(data: any): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',   
      'Licencia': conexion.licencia     
   });
    let options = { headers: headers };
    return this.http.post<any>(`${this.apiUrl}empresas`, data,options);
  }

    actualizarEmpresa(
    id: number,
    payload: {
      s_nombre_empresa: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}empresas/${id}`,
      payload,
      this.options
    );
  }

  eliminaEmpresa(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}empresas/${id}`,
      payload,
      this.options
    );
  }

 
}


