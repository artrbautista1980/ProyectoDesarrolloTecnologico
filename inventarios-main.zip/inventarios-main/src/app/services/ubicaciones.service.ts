import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UbicacionesService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getUbicacion(id_modelo: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}ubicaciones/${id_modelo}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS UBICACIONES
  // ======================
  getUbicaciones(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}ubicaciones`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearUbicacion(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}ubicaciones`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarUbicacion(
    id: number,
    payload: {
      s_ubicacion: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}ubicaciones/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaUbicacion(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}ubicaciones/${id}`,
      payload,
      this.options
    );
  }

}
