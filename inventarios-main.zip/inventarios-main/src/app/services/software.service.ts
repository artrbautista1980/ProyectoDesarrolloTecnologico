import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SoftwareService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getSoftware(id_modelo: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}software/${id_modelo}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS software
  // ======================
  getSoftware_(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}software`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearSoftware(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}software`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarSoftware(
    id: number,
    payload: {
      s_nombre_software_instalado: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}software/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaSoftware(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}software/${id}`,
      payload,
      this.options
    );
  }

}
