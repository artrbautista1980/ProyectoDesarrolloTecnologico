import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FacturasService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UNA facturas
  // ======================
  getfactura(id_factura: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}facturas/${id_factura}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS facturass
  // ======================
  getfacturas(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}facturas`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
crearfacturas(data: FormData): Observable<any> {

  const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });

  return this.http.post<any>(
    `${this.apiUrl}facturas`,
    data,
    { headers }
  );
}

actualizarFactura(id: number, data: any) {
    const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });
    return this.http.put(`${this.apiUrl}facturas/${id}`, data, { headers });
  }

  eliminarFactura(id: number) {
      const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });
    return this.http.delete(`${this.apiUrl}facturas/${id}`,this.options);
  }
 
}
