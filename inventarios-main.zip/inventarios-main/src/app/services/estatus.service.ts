import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EstatusService {
  private apiUrl = conexion.url;
    // 🔐 Headers personalizados con Licencia
    private headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Licencia': conexion.licencia
    });
  
    // Opciones reutilizables
    private options = {
      headers: this.headers
    };

  constructor(
  private http: HttpClient
    ) { }

  getEstatus(id_estatus : any){
    
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',   
        'Licencia': conexion.licencia     
     });
    let options = { headers: headers };
    const data = {}
    let url=conexion.url+"estatus/"+id_estatus;
    
    return this.http.get(url,options);
  }

/*   getestatus(){
    
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',   
        'Licencia': conexion.licencia     
     });
    let options = { headers: headers };
    const data = {}
    let url=conexion.url+"cards/"+id_estatus;
    
    return this.http.get(url,options);
  } */
  getallEstatus(): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',   
      'Licencia': conexion.licencia     
   });
    let options = { headers: headers };
    return this.http.get(this.apiUrl+'estatus',options);
  }
  crearEstatus(data: any): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',   
      'Licencia': conexion.licencia     
   });
    let options = { headers: headers };
    return this.http.post<any>(`${this.apiUrl}estatus`, data,options);
  }

    actualizarEstatus(
    id: number,
    payload: {
      s_nombre_estatus: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}estatus/${id}`,
      payload,
      this.options
    );
  }

  eliminaEstatus(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}estatus/${id}`,
      payload,
      this.options
    );
  }

 
}


