import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';


@Injectable({
  providedIn: 'root'
})
export class VcardService {
  constructor(
  private http: HttpClient
    ) { }

  getContact(id_contacto : any){
    
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',   
        'Licencia': conexion.licencia     
     });
    let options = { headers: headers };
    const data = {}
    let url=conexion.url+"cards/"+id_contacto;
    
    return this.http.get(url,options);
  }
 
}


