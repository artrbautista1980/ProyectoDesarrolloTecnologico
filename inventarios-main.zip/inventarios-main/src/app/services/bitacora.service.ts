import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BitacoraService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UNA BITACORA
  // ======================
  getBitacora(id_bitacora: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}bitacora/${id_bitacora}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS bitacoras
  // ======================
  getBitacoras(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}bitacora`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
crearBitacora(data: FormData): Observable<any> {

  const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });

  return this.http.post<any>(
    `${this.apiUrl}bitacora`,
    data,
    { headers }
  );
}
 
}
