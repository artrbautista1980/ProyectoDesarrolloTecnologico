import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class InventariosService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getInventario(id_empleado: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}inventarios/${id_empleado}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS inventarios
  // ======================
  getInventarios(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}inventarios`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
crearInventario(data: FormData): Observable<any> {

  const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });

  return this.http.post<any>(
    `${this.apiUrl}inventarios`,
    data,
    { headers }
  );
}

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarInvenario(
    id: number,
   data: any
    
  ): Observable<any> {
     const headers = new HttpHeaders({
    'Licencia': conexion.licencia
  });
    return this.http.put<any>(
      `${this.apiUrl}inventarios/${id}`,
      data,
       { headers }
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaInventario(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}inventarios/${id}`,
      payload,
      this.options
    );
  }

}
