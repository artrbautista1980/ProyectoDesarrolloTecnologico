import { TestBed } from '@angular/core/testing';

import { TiposEquiposService } from './tipos-equipos.service';

describe('TiposEquiposService', () => {
  let service: TiposEquiposService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TiposEquiposService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
