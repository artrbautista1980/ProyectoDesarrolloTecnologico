import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getEmpleado(id_empleado: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}empleados/${id_empleado}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS empleados
  // ======================
  getEmpleados(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}empleados`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearEmpleado(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}empleados`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarEmpleado(
    id: number,
    payload: {
      s_nombre: string;
      s_apaterno: string;
      s_amaterno: string;
      n_noempleado: string;
      id_empresa: string;
      id_ubicacion: string;
      email: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}empleados/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaEmpleado(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}empleados/${id}`,
      payload,
      this.options
    );
  }

}
