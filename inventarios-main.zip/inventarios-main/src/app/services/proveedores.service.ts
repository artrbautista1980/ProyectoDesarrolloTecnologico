import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProveedoresService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getProveedor(id_modelo: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}proveedores/${id_modelo}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS MODELOS
  // ======================
  getProveedores(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}proveedores`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearProveedor(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}proveedores`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarProveedor(
    id: number,
    payload: {
      s_nombre_empresa: string;
      s_contacto: string;
      s_email : string;
      n_telefono : string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}proveedores/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaProveedor(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}proveedores/${id}`,
      payload,
      this.options
    );
  }

}
