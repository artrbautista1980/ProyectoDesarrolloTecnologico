import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { conexion } from '../conexion';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'http://localhost/api'; // cambia si es servidor

  constructor(private http: HttpClient) {}

  login(data: any): Observable<any> {
    let headers = new HttpHeaders({
            'Content-Type': 'application/json',   
            'Licencia': conexion.licencia     
         });
        let options = { headers: headers };
        console.log(`${conexion.url}login`)
    return this.http.post(`${conexion.url}login`, data , options);
  }

  register(data: any): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',   
      'Licencia': conexion.licencia     
   });
  let options = { headers: headers };
    return this.http.post(`${conexion.url}register`, data, options);
  }
  logout() {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Licencia': conexion.licencia
    });
  
    return this.http.post(`${conexion.url}logout`, {}, { headers });
  }
}