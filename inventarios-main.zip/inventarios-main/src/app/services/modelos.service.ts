import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModelosService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getModelo(id_modelo: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}modelos/${id_modelo}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS MODELOS
  // ======================
  getModelos(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}modelos`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearModelo(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}modelos`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarModelo(
    id: number,
    payload: {
      s_nombre_modelo: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}modelos/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaModelo(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}modelos/${id}`,
      payload,
      this.options
    );
  }

}
