import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TiposEquiposService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UN MODELO
  // ======================
  getTipo(id_modelo: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}tiposequipo/${id_modelo}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODOS LOS MODELOS
  // ======================
  getTipos(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}tiposequipo`,
      this.options
    );
  }

  // ======================
  // CREAR MODELO
  // ======================
  crearTipo(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}tiposequipo`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MODELO
  // ======================
  actualizarTipo(
    id: number,
    payload: {
      s_nombre_tipo_equipo: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}tiposequipo/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MODELO
  // ======================
  eliminaTipo(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}tiposequipo/${id}`,
      payload,
      this.options
    );
  }

}
