import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { conexion } from '../conexion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MarcasService {

  private apiUrl = conexion.url;

  // 🔐 Headers personalizados con Licencia
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Licencia': conexion.licencia
  });

  // Opciones reutilizables
  private options = {
    headers: this.headers
  };

  constructor(private http: HttpClient) {}

  // ======================
  // OBTENER UNA MARCA
  // ======================
  getMarca(id_marca: any): Observable<any> {
    return this.http.get(
      `${this.apiUrl}marcas/${id_marca}`,
      this.options
    );
  }

  // ======================
  // OBTENER TODAS LAS MARCAS
  // ======================
  getMarcas(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}marcas`,
      this.options
    );
  }

  // ======================
  // CREAR MARCA
  // ======================
  crearMarca(data: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}marcas`,
      data,
      this.options
    );
  }

  // ======================
  // ACTUALIZAR MARCA
  // ======================
  actualizarMarca(
    id: number,
    payload: {
      s_marca: string;
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}marcas/${id}`,
      payload,
      this.options
    );
  }

  // ======================
  // ELIMINAR (DESACTIVAR) MARCA
  // ======================
  eliminaMarca(
    id: number,
    payload: {
      active: number;
    }
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}marcas/${id}`,
      payload,
      this.options
    );
  }

}
