import { Component, OnInit, AfterViewInit } from '@angular/core';
import { TiposEquiposService } from 'src/app/services/tipos-equipos.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-tipos-equipos',
  templateUrl: './tipos-equipos.component.html',
  styleUrls: ['./tipos-equipos.component.scss']
})
export class TiposEquiposComponent implements OnInit, AfterViewInit {

  tipoForm!: FormGroup;
  tipos: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editartipoForm!: FormGroup;
  tipoEditandoId: number | null = null;
  tipoEliminarId: number | null = null;
  tipoEliminarNombre: string = '';

  constructor(
    private tiposEquiposService: TiposEquiposService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.tipoForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editartipoForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargartipos();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#tiposTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#tiposTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#tiposTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarMarca(id, nombre);
  });
  
  }

  // ======================
  // CARGAR tipos
  // ======================
  cargartipos(): void {
    this.tiposEquiposService.getTipos().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Modelo guardada correctamente');
    
    
        this.tipos = resp.data.tiposequipos;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.tipos.forEach(e => {
      this.dataTable.row.add([
        e.id_tipo_equipo,
        e.s_nombre_tipo_equipo,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_tipo_equipo}"
            data-nombre="${e.s_nombre_tipo_equipo}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_tipo_equipo}"
            data-nombre="${e.s_nombre_tipo_equipo}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR EMPRESA
  // ======================
  guardarModelo(): void {
    if (this.tipoForm.invalid) {
      this.tipoForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_tipo_equipo: this.tipoForm.value.nombre,
      active: true
    };

    this.tiposEquiposService.crearTipo(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Modelo guardada correctamente');

        // 🔄 recargar lista
        this.cargartipos();

        this.tipoForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarModelo(): void {
    if (this.editartipoForm.invalid || !this.tipoEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_nombre_tipo_equipo: this.editartipoForm.value.nombre,
      active: 1
    };
  
    this.tiposEquiposService.actualizarTipo(this.tipoEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Modelo actualizada');
  
        this.cargartipos();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar modelo');
      }
    });
  }
  confirmarEliminarMarca(id: number, nombre: string): void {
    this.tipoEliminarId = id;
    this.tipoEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.tipoEliminarId) return;
  
    this.eliminarModelo(this.tipoEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarModelo(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.tiposEquiposService.eliminaTipo(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empresa desactivada');
  
        // 🔄 Refrescar tabla
        this.cargartipos();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empresa');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('modeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarModeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.tipoEliminarId = null;
    this.tipoEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.tipoEditandoId = id;
  
    this.editartipoForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarModeloModal')
    );
  
    modal.show();
  }
  
}
