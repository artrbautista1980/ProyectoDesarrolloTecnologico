import { Component, OnInit, AfterViewInit } from '@angular/core';
import { EmpresasService } from 'src/app/services/empresas.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-empresas',
  templateUrl: './empresas.component.html',
  styleUrls: ['./empresas.component.scss']
})
export class EmpresasComponent implements OnInit, AfterViewInit {

  empresaForm!: FormGroup;
  empresas: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarEmpresaForm!: FormGroup;
  empresaEditandoId: number | null = null;
  empresaEliminarId: number | null = null;
  empresaEliminarNombre: string = '';

  constructor(
    private empresasService: EmpresasService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.empresaForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarEmpresaForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarEmpresas();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#empresasTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#empresasTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#empresasTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarEmpresa(id, nombre);
  });
  
  }

  // ======================
  // CARGAR EMPRESAS
  // ======================
  cargarEmpresas(): void {
    this.empresasService.getEmpresas().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Empresa guardada correctamente');
    
    
        this.empresas = resp.data.empresas;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.empresas.forEach(e => {
      this.dataTable.row.add([
        e.id_empresa,
        e.s_nombre_empresa,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_empresa}"
            data-nombre="${e.s_nombre_empresa}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_empresa}"
            data-nombre="${e.s_nombre_empresa}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR EMPRESA
  // ======================
  guardarEmpresa(): void {
    if (this.empresaForm.invalid) {
      this.empresaForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_empresa: this.empresaForm.value.nombre,
      active: true
    };

    this.empresasService.crearEmpresa(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Empresa guardada correctamente');

        // 🔄 recargar lista
        this.cargarEmpresas();

        this.empresaForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarEmpresa(): void {
    if (this.editarEmpresaForm.invalid || !this.empresaEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_nombre_empresa: this.editarEmpresaForm.value.nombre,
      active: 1
    };
  
    this.empresasService.actualizarEmpresa(this.empresaEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Empresa actualizada');
  
        this.cargarEmpresas();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar empresa');
      }
    });
  }
  confirmarEliminarEmpresa(id: number, nombre: string): void {
    this.empresaEliminarId = id;
    this.empresaEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.empresaEliminarId) return;
  
    this.eliminarEmpresa(this.empresaEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarEmpresa(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.empresasService.eliminaEmpresa(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empresa desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarEmpresas();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empresa');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('empresaModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarEmpresaModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.empresaEliminarId = null;
    this.empresaEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.empresaEditandoId = id;
  
    this.editarEmpresaForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarEmpresaModal')
    );
  
    modal.show();
  }
  
}
