
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmpresasService } from 'src/app/services/empresas.service';
import { UbicacionesService } from 'src/app/services/ubicaciones.service';
import { forkJoin } from 'rxjs';

declare var $: any;

@Component({
  selector: 'app-empleados',
  templateUrl: './empleados.component.html',
  styleUrls: ['./empleados.component.scss']
})
export class EmpleadosComponent implements OnInit, AfterViewInit {

  empleadosForm!: FormGroup;
  empleados: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  empresas: any[] = [];
  ubicaciones: any[] = [];
  editarempleadosForm!: FormGroup;
  empleadoEditandoId: number | null = null;
  empleadoEliminarId: number | null = null;
  empleadoEliminarNombre: string = '';

  constructor(
    private empleadosService: EmpleadosService,
    private empresasService: EmpresasService,
    private ubicacionesService: UbicacionesService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
   this.empleadosForm = this.fb.group({
  nombre: ['', Validators.required],
  apaterno: ['', Validators.required],
  amaterno: [''],
  noempleado: ['', Validators.required],
  id_empresa: ['', Validators.required],
  id_ubicacion: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]]
});

this.editarempleadosForm = this.fb.group({
  nombre: ['', Validators.required],
  apaterno: ['', Validators.required],
  amaterno: [''],
  noempleado: ['', Validators.required],
  id_empresa: ['', Validators.required],
  id_ubicacion: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]]
});
    
    
    this.cargarDatos();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#empleadosTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#empleadosTable tbody').on('click', '.btn-editar', (event: any) => {
   
  const button = $(event.currentTarget);

  this.abrirModalEditar(
    button.data('id'),
    button.data('nombre'),
    button.data('apaterno'),
    button.data('amaterno'),
    button.data('noempleado'),
    button.data('empresa'),
    button.data('ubicacion'),
    button.data('email')
  );
  });
  $('#empleadosTable tbody').on('click', '.btn-eliminar', (event: any) => {
  const button = $(event.currentTarget);

  const id = button.data('id');
  const nombre = button.data('nombre');
  const apaterno = button.data('apaterno');
  const amaterno = button.data('amaterno');
  const noempleado = button.data('noempleado');
  const empresa = button.data('empresa');
  const email = button.data('email');

  // Nombre completo para mostrar en el modal
  const nombreCompleto = `${nombre} ${apaterno} ${amaterno}`;

  this.confirmarEliminarEmpleado(id, nombreCompleto);
});
  
  }
  cargarDatos(): void {

  forkJoin({
    empresas: this.empresasService.getEmpresas(),
    ubicaciones: this.ubicacionesService.getUbicaciones(),
    empleados: this.empleadosService.getEmpleados()
  }).subscribe({
    next: (resp: any) => {

      this.empresas = resp.empresas.data.empresas;
      this.ubicaciones = resp.ubicaciones.data.ubicaciones;
      this.empleados = resp.empleados.data.empleados;

      this.refrescarDataTable(); // 🔥 ya todo está cargado
    },
    error: (err) => console.error(err)
  });
}

  cargarEmpresas(): void {
  this.empresasService.getEmpresas().subscribe({
    next: (resp: any) => {
      this.empresas = resp.data.empresas;
    },
    error: (err) => console.error(err)
  });
}
obtenerNombreEmpresa(id: number): string {
  const empresa = this.empresas.find(e => e.id_empresa === id);
  return empresa ? empresa.s_nombre_empresa : 'Sin empresa';
}
obtenerNombreUbicacion(id: number): string {
  const ubicacion = this.ubicaciones.find(u => u.id_ubicacion === id);
  return ubicacion ? ubicacion.s_ubicacion : 'Sin ubicación';
}
  // ======================
  // CARGAR empleados
  // ======================
  cargarempleados(): void {
    this.empleadosService.getEmpleados().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Ubicacion guardada correctamente');
    
    
        this.empleados = resp.data.empleados;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.empleados.forEach(e => {
  this.dataTable.row.add([
    e.id_empleado,
    e.s_nombre,
    e.s_apaterno,
    e.s_amaterno,
    e.n_noempleado,
    this.obtenerNombreEmpresa(e.id_empresa),
    this.obtenerNombreUbicacion(e.id_ubicacion),
    e.email,
    (e.active === true || e.active === 1 || e.active === '1')
      ? '<span class="badge bg-success">Activo</span>'
      : '<span class="badge bg-danger">Inactivo</span>',
    `
      <button class="btn btn-sm btn-warning me-2 btn-editar"
        data-id="${e.id_empleado}"
        data-nombre="${e.s_nombre}"
        data-apaterno="${e.s_apaterno}"
        data-amaterno="${e.s_amaterno}"
        data-noempleado="${e.n_noempleado}"
        data-empresa="${e.id_empresa}"
        data-ubicacion="${e.id_ubicacion}"
        data-email="${e.email}">
        <i class="fas fa-edit"></i>
      </button>
  
      <button class="btn btn-sm btn-danger btn-eliminar"
        data-id="${e.id_empleado}"
        data-nombre="${e.s_nombre}"
        data-apaterno="${e.s_apaterno}"
        data-amaterno="${e.s_amaterno}"
        
        >
        <i class="fas fa-trash"></i>
      </button>
    `
  ]);
});

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR Ubicacion
  // ======================
  guardarEmpleado(): void {
    if (this.empleadosForm.invalid) {
      this.empleadosForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre: this.empleadosForm.value.nombre,
      s_apaterno: this.empleadosForm.value.apaterno,
      s_amaterno: this.empleadosForm.value.amaterno,
      n_noempleado: this.empleadosForm.value.noempleado,
      id_empresa: this.empleadosForm.value.id_empresa,
      id_ubicacion: this.empleadosForm.value.id_ubicacion,
      email: this.empleadosForm.value.email,
      active: true
    };

    this.empleadosService.crearEmpleado(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Empleado guardada correctamente');

        // 🔄 recargar lista
        this.cargarempleados();

        this.empleadosForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarEmpleado(): void {
    if (this.editarempleadosForm.invalid || !this.empleadoEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
     s_nombre: this.editarempleadosForm.value.nombre,
      s_apaterno: this.editarempleadosForm.value.apaterno,
      s_amaterno: this.editarempleadosForm.value.amaterno,
      n_noempleado: this.editarempleadosForm.value.noempleado,
      id_empresa: this.editarempleadosForm.value.id_empresa,
      id_ubicacion: this.editarempleadosForm.value.id_ubicacion,
      email: this.editarempleadosForm.value.email,
      active: 1
    };
  
    this.empleadosService.actualizarEmpleado(this.empleadoEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Empleado actualizada');
  
        this.cargarempleados();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar empleado');
      }
    });
  }
  confirmarEliminarEmpleado(id: number, nombre: string): void {
    this.empleadoEliminarId = id;
    this.empleadoEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.empleadoEliminarId) return;
  
    this.eliminarEmpleado(this.empleadoEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarEmpleado(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.empleadosService.eliminaEmpleado(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empleado desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarempleados();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empleado');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('modeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarModeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.empleadoEliminarId = null;
    this.empleadoEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  
  abrirModalEditar(
  id: number,
  nombre: string,
  apaterno: string,
  amaterno: string,
  noempleado: string,
  id_empresa: number,
  id_ubicacion: number,
  email: string
): void {

  this.empleadoEditandoId = id;

  this.editarempleadosForm.patchValue({
    nombre: nombre,
    apaterno: apaterno,
    amaterno: amaterno,
    noempleado: noempleado,
    id_empresa: id_empresa,
    id_ubicacion: id_ubicacion,
    email: email
  });

  const modal = new (window as any).bootstrap.Modal(
    document.getElementById('editarModeloModal')
  );

  modal.show();
}
  
}
