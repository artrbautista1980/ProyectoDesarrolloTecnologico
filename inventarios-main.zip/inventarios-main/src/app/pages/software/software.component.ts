import { Component, OnInit, AfterViewInit } from '@angular/core';
import { SoftwareService } from 'src/app/services/software.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-software',
  templateUrl: './software.component.html',
  styleUrls: ['./software.component.scss']
})
export class SoftwareComponent implements OnInit, AfterViewInit {

  softwareForm!: FormGroup;
  software_: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarsoftwareForm!: FormGroup;
  softwareEditandoId: number | null = null;
  softwareEliminarId: number | null = null;
  softwareEliminarNombre: string = '';

  constructor(
    private softwareService: SoftwareService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.softwareForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarsoftwareForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarsoftware_();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#software_Table').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#software_Table tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#software_Table tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarMarca(id, nombre);
  });
  
  }

  // ======================
  // CARGAR software_
  // ======================
  cargarsoftware_(): void {
    this.softwareService.getSoftware_().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Software guardada correctamente');
    
    
        this.software_ = resp.data.softwareinstalados;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.software_.forEach(e => {
      this.dataTable.row.add([
        e.id_software_instalado,
        e.s_nombre_software_instalado,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_software_instalado}"
            data-nombre="${e.s_nombre_software_instalado}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_software_instalado}"
            data-nombre="${e.s_nombre_software_instalado}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR EMPRESA
  // ======================
  guardarSoftware(): void {
    if (this.softwareForm.invalid) {
      this.softwareForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_software_instalado: this.softwareForm.value.nombre,
      active: true
    };

    this.softwareService.crearSoftware(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Software guardada correctamente');

        // 🔄 recargar lista
        this.cargarsoftware_();

        this.softwareForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarSoftware(): void {
    if (this.editarsoftwareForm.invalid || !this.softwareEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_nombre_software_instalado: this.editarsoftwareForm.value.nombre,
      active: 1
    };
  
    this.softwareService.actualizarSoftware(this.softwareEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Software actualizada');
  
        this.cargarsoftware_();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar Software');
      }
    });
  }
  confirmarEliminarMarca(id: number, nombre: string): void {
    this.softwareEliminarId = id;
    this.softwareEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.softwareEliminarId) return;
  
    this.eliminarSoftware(this.softwareEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarSoftware(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.softwareService.eliminaSoftware(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empresa desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarsoftware_();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empresa');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('softwareModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarSoftwareModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.softwareEliminarId = null;
    this.softwareEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.softwareEditandoId = id;
  
    this.editarsoftwareForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarSoftwareModal')
    );
  
    modal.show();
  }
  
}
