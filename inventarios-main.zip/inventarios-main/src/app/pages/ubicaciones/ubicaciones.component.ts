import { Component, OnInit, AfterViewInit } from '@angular/core';
import { UbicacionesService } from 'src/app/services/ubicaciones.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-ubicaciones',
  templateUrl: './ubicaciones.component.html',
  styleUrls: ['./ubicaciones.component.scss']
})
export class UbicacionesComponent implements OnInit, AfterViewInit {

  ubicacionesForm!: FormGroup;
  ubicaciones: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarubicacionesForm!: FormGroup;
  ubicacionEditandoId: number | null = null;
  ubicacionEliminarId: number | null = null;
  ubicacionEliminarNombre: string = '';

  constructor(
    private ubicacionesService: UbicacionesService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.ubicacionesForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarubicacionesForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarubicaciones();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#ubicacionesTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#ubicacionesTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#ubicacionesTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarUbicacion(id, nombre);
  });
  
  }

  // ======================
  // CARGAR ubicaciones
  // ======================
  cargarubicaciones(): void {
    this.ubicacionesService.getUbicaciones().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Ubicacion guardada correctamente');
    
    
        this.ubicaciones = resp.data.ubicaciones;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.ubicaciones.forEach(e => {
      this.dataTable.row.add([
        e.id_ubicacion,
        e.s_ubicacion,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_ubicacion}"
            data-nombre="${e.s_ubicacion}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_ubicacion}"
            data-nombre="${e.s_ubicacion}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR Ubicacion
  // ======================
  guardarModelo(): void {
    if (this.ubicacionesForm.invalid) {
      this.ubicacionesForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_ubicacion: this.ubicacionesForm.value.nombre,
      active: true
    };

    this.ubicacionesService.crearUbicacion(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Ubicacion guardada correctamente');

        // 🔄 recargar lista
        this.cargarubicaciones();

        this.ubicacionesForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarModelo(): void {
    if (this.editarubicacionesForm.invalid || !this.ubicacionEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_ubicacion: this.editarubicacionesForm.value.nombre,
      active: 1
    };
  
    this.ubicacionesService.actualizarUbicacion(this.ubicacionEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Modelo actualizada');
  
        this.cargarubicaciones();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar modelo');
      }
    });
  }
  confirmarEliminarUbicacion(id: number, nombre: string): void {
    this.ubicacionEliminarId = id;
    this.ubicacionEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.ubicacionEliminarId) return;
  
    this.eliminarModelo(this.ubicacionEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarModelo(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.ubicacionesService.eliminaUbicacion(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Ubicacion desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarubicaciones();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar Ubicacion');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('modeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarModeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.ubicacionEliminarId = null;
    this.ubicacionEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.ubicacionEditandoId = id;
  
    this.editarubicacionesForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarModeloModal')
    );
  
    modal.show();
  }
  
}
