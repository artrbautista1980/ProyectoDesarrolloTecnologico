import { Component, OnInit } from '@angular/core';
import { FacturasService } from 'src/app/services/facturas.service';
import { ProveedoresService } from 'src/app/services/proveedores.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AfterViewInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-facturas',
  templateUrl: './facturas.component.html',
  styleUrls: ['./facturas.component.scss']
})
export class FacturasComponent implements OnInit, AfterViewInit  {

  facturas: any[] = [];
  proveedores: any[] = [];
  dataTable: any;
  facturaSeleccionada: any = null;
  cargando = false;
  pdfUrl: SafeResourceUrl | null = null;
  idEliminar: number | null = null;
  facturaForm!: FormGroup;
  archivoFactura: File | null = null;
  modoEdicion = false;
  idEditando: number | null = null;
  constructor(
    private facturasService: FacturasService,
    private proveedoresService: ProveedoresService,
    private sanitizer: DomSanitizer,
    private fb: FormBuilder
  ) {}

   ngAfterViewInit(): void {

    this.dataTable = $('#facturasTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });

    // 🔥 EDITAR
    $('#facturasTable tbody').on('click', '.btn-editar', (event: any) => {
      const id = $(event.currentTarget).data('id');
      const factura = this.facturas.find(f => f.id_factura == id);
      if (factura) this.cargarParaEditar(factura);
    });

    // 🔥 ELIMINAR
    $('#facturasTable tbody').on('click', '.btn-eliminar', (event: any) => {
  const id = $(event.currentTarget).data('id');

  this.idEliminar = id;

  const modal = new (window as any).bootstrap.Modal(
    document.getElementById('modalConfirm')
  );
  modal.show();
  });

    // 🔥 VER PDF
    $('#facturasTable tbody').on('click', '.btn-ver', (event: any) => {
      const id = $(event.currentTarget).data('id');
      const factura = this.facturas.find(f => f.id_factura == id);
      if (factura) this.seleccionarFactura(factura);
    });

    // 🔥 DESCARGAR
    $('#facturasTable tbody').on('click', '.btn-download', (event: any) => {
      const id = $(event.currentTarget).data('id');
      const factura = this.facturas.find(f => f.id_factura == id);
      if (factura) this.descargarPDF(factura);
    });
  }
  ngOnInit(): void {
    this.inicializarFormulario();
    this.cargarDatos(); // 🔥 YA EXISTE
  }

  // ============================
  // 🔥 CARGAR DATOS
  // ============================
  refrescarDataTable(): void {

  if (!this.dataTable) return;

  this.dataTable.clear();

  this.facturas.forEach(f => {

    this.dataTable.row.add([
      f.id_factura,
      this.obtenerNombreProveedor(f.id_proveedor),
      f.d_fecha_facturacion,
      f.s_folio_factura,
      f.n_numero_orden,
      f.id_inventario,

      `
      <div class="d-flex gap-2 justify-content-center">

        <!-- 👁 VER -->
        <button class="btn btn-sm btn-outline-primary btn-ver"
                title="Ver PDF"
                data-id="${f.id_factura}">
          <i class="bi bi-eye"></i>
        </button>

        <!-- ✏️ EDITAR -->
        <button class="btn btn-sm btn-outline-warning btn-editar"
                title="Editar"
                data-id="${f.id_factura}">
          <i class="bi bi-pencil"></i>
        </button>

        <!-- ⬇️ DESCARGAR -->
        <button class="btn btn-sm btn-outline-success btn-descargar"
                title="Descargar PDF"
                data-id="${f.id_factura}">
          <i class="bi bi-download"></i>
        </button>

        <!-- 🗑 ELIMINAR -->
        <button class="btn btn-sm btn-outline-danger btn-eliminar"
                title="Eliminar"
                data-id="${f.id_factura}">
          <i class="bi bi-trash"></i>
        </button>

      </div>
      `,
   
    ]);

  });

  this.dataTable.draw(false);
}
  cargarDatos(): void {
  this.cargando = true;

  forkJoin({
    facturas: this.facturasService.getfacturas(),
    proveedores: this.proveedoresService.getProveedores()
  }).subscribe({
    next: (resp: any) => {

      this.facturas = resp.facturas?.data?.facturas || [];
      this.proveedores = resp.proveedores?.data?.proveedores || [];

      this.refrescarDataTable(); // 🔥 IMPORTANTE

      this.cargando = false;
    },
    error: (err) => {
      console.error(err);
      this.cargando = false;
    }
  });
}

  // ============================
  // 🔥 FORMULARIO
  // ============================
  inicializarFormulario(): void {
    this.facturaForm = this.fb.group({
      d_fecha_facturacion: ['', Validators.required],
      id_proveedor: ['', Validators.required],
      n_numero_orden: [''],
      s_folio_factura: [''],
      id_inventario: ['', Validators.required],
      s_factura: [null]
    });
  }

  // ============================
  // 🔥 NOMBRE PROVEEDOR
  // ============================
  obtenerNombreProveedor(id: number): string {
    const proveedor = this.proveedores.find(p => p.id_proveedor == id);
    return proveedor ? proveedor.s_nombre_empresa : 'N/A';
  }

  // ============================
  // 🔥 SELECCIONAR FACTURA
  // ============================
 seleccionarFactura(factura: any): void {

  this.pdfUrl = null; // 🔥 limpia primero

  setTimeout(() => {
    if (factura?.s_factura_pdf) {
      this.pdfUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `data:application/pdf;base64,${factura.s_factura_pdf}`
      );
    }
  }, 100);

  this.facturaSeleccionada = factura;

  const modal = new (window as any).bootstrap.Modal(
    document.getElementById('modalPdf')
  );
  modal.show();
}

  // ============================
  // 🔥 ARCHIVO PDF
  // ============================
  onFileSelected(event: any): void {
    const file = event.target.files[0];

    if (!file) return;

    if (file.type !== 'application/pdf') {
  this.mostrarToast('Solo se permiten archivos PDF', 'warning');
  return;
}

if (file.size > 1024 * 1024) {
  this.mostrarToast('El PDF no debe superar 1 MB', 'warning');
  return;
}

    this.archivoFactura = file;
  }

  convertirABase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  }

  // ============================
  // 🔥 GUARDAR FACTURA
  // ============================
async guardarFactura(): Promise<void> {

  if (this.facturaForm.invalid) {
    this.facturaForm.markAllAsTouched();
    return;
  }

  this.cargando = true;

  let base64 = null;

  if (this.archivoFactura) {
    base64 = await this.convertirABase64(this.archivoFactura);
    if (base64.includes('base64,')) {
      base64 = base64.split('base64,')[1];
    }
  }

  const payload: any = {
    ...this.facturaForm.value,
    s_factura_pdf: base64
  };

  let request;

  if (this.modoEdicion) {
    request = this.facturasService.actualizarFactura(this.idEditando!, payload);
  } else {
    request = this.facturasService.crearfacturas(payload);
  }

  request.subscribe({
    next: () => {
        this.mostrarToast('Factura guardada correctamente', 'success');

      this.facturaForm.reset();
      this.archivoFactura = null;
      this.modoEdicion = false;
      this.idEditando = null;

      this.cerrarModal();
      this.cargarDatos();
      this.cargando = false;
    },
    error: (err) => {
      console.error(err);
      this.mostrarToast('Error al guardar la factura', 'error');
      this.cargando = false;
    }
  });
}

  // ============================
  // 🔥 MODAL
  // ============================
  abrirModal(): void {
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('modalFactura')
    );
    modal.show();
  }

  cerrarModal(): void {
    const modal = (window as any).bootstrap.Modal.getInstance(
      document.getElementById('modalFactura')
    );
    if (modal) modal.hide();
  }
  cargarParaEditar(factura: any): void {

  this.modoEdicion = true;
  this.idEditando = factura.id_factura;

  this.facturaForm.patchValue({
    d_fecha_facturacion: factura.d_fecha_facturacion,
    id_proveedor: factura.id_proveedor,
    n_numero_orden: factura.n_numero_orden,
    s_folio_factura: factura.s_folio_factura,
    id_inventario: factura.id_inventario
  });

  this.abrirModal();
}

confirmarEliminar(): void {

  if (!this.idEliminar) return;

  this.facturasService.eliminarFactura(this.idEliminar).subscribe({
    next: () => {

      this.mostrarToast('Factura eliminada correctamente', 'success');
      this.cargarDatos();

      this.cerrarModalConfirm();

    },
    error: (err) => {
      console.error(err);
      this.mostrarToast('Error al eliminar la factura', 'error');
    }
  });
}
cerrarModalConfirm(): void {
  const modal = (window as any).bootstrap.Modal.getInstance(
    document.getElementById('modalConfirm')
  );
  if (modal) modal.hide();
}
descargarPDF(factura: any): void {

  const linkSource = `data:application/pdf;base64,${factura.s_factura_pdf}`;
  const downloadLink = document.createElement('a');

  downloadLink.href = linkSource;
  downloadLink.download = `Factura_${factura.id_factura}.pdf`;

  downloadLink.click();
}
mostrarToast(mensaje: string, tipo: 'success' | 'error' | 'warning' = 'success'): void {

  const toastEl = document.getElementById('toastMsg');
  const toastBody = document.getElementById('toastBody');

  if (!toastEl || !toastBody) return;

  // 🔥 colores dinámicos
  toastEl.classList.remove('bg-success', 'bg-danger', 'bg-warning');

  if (tipo === 'success') toastEl.classList.add('bg-success');
  if (tipo === 'error') toastEl.classList.add('bg-danger');
  if (tipo === 'warning') toastEl.classList.add('bg-warning');

  toastBody.innerText = mensaje;

  const toast = new (window as any).bootstrap.Toast(toastEl, {
    delay: 3000 // 🔥 se desvanece en 3s
  });

  toast.show();
}
}