import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ProveedoresService } from 'src/app/services/proveedores.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-proveedores',
  templateUrl: './proveedores.component.html',
  styleUrls: ['./proveedores.component.scss']
})
export class ProveedoresComponent implements OnInit, AfterViewInit {

  proveedorForm!: FormGroup;
  editarproveedorForm!: FormGroup;

  proveedores: any[] = [];
  cargando = false;
  dataTable: any;

  proveedorEditandoId: number | null = null;
  proveedorEliminarId: number | null = null;
  proveedorEliminarNombre: string = '';

  toasts: string[] = [];

  constructor(
    private proveedoresService: ProveedoresService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {

    this.proveedorForm = this.fb.group({
      nombre: ['', Validators.required],
      contacto: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', Validators.required]
    });

    this.editarproveedorForm = this.fb.group({
      nombre: ['', Validators.required],
      contacto: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', Validators.required]
    });

    this.cargarproveedores();
  }

  // ======================
  // DATATABLE
  // ======================
  ngAfterViewInit(): void {

    this.dataTable = $('#proveedoresTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });

    // Evento editar
    $('#proveedoresTable tbody').on('click', '.btn-editar', (event: any) => {
      const button = $(event.currentTarget);

      this.abrirModalEditar(
        button.data('id'),
        button.data('nombre'),
        button.data('contacto'),
        button.data('email'),
        button.data('telefono')
      );
    });

    // Evento eliminar
    $('#proveedoresTable tbody').on('click', '.btn-eliminar', (event: any) => {
      const button = $(event.currentTarget);
      this.confirmarEliminarProveedor(
        button.data('id'),
        button.data('nombre')
      );
    });
  }

  // ======================
  // CARGAR
  // ======================
  cargarproveedores(): void {

    this.cargando = true;

    this.proveedoresService.getProveedores().subscribe({
      next: (resp: any) => {

        this.cargando = false;
        this.proveedores = resp.data.proveedores;
        this.refrescarDataTable();

      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }

  // ======================
  // REFRESCAR TABLA
  // ======================
  refrescarDataTable(): void {

    if (!this.dataTable) return;

    this.dataTable.clear();

    this.proveedores.forEach(e => {

      this.dataTable.row.add([
        e.id_proveedor,
        e.s_nombre_empresa,
        e.s_contacto,
        e.s_email,
        e.n_telefono,
        (e.active == 1)
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
        <button class="btn btn-sm btn-warning me-2 btn-editar"
          data-id="${e.id_proveedor}"
          data-nombre="${e.s_nombre_empresa}"
          data-contacto="${e.s_contacto}"
          data-email="${e.s_email}"
          data-telefono="${e.n_telefono}">
          <i class="fas fa-edit"></i>
        </button>

        <button class="btn btn-sm btn-danger btn-eliminar"
          data-id="${e.id_proveedor}"
          data-nombre="${e.s_nombre_empresa}">
          <i class="fas fa-trash"></i>
        </button>
        `
      ]);

    });

    this.dataTable.draw();
  }

  // ======================
  // GUARDAR
  // ======================
  guardarProveedor(): void {

    if (this.proveedorForm.invalid) {
      this.proveedorForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_empresa: this.proveedorForm.value.nombre,
      s_contacto: this.proveedorForm.value.contacto,
      s_email: this.proveedorForm.value.email,
      n_telefono: this.proveedorForm.value.telefono,
      active: 1
    };

    this.proveedoresService.crearProveedor(payload).subscribe({
      next: (resp: any) => {

        this.cargando = false;
        this.mostrarToast(resp.message || 'Proveedor guardado');

        this.proveedorForm.reset();
        this.cerrarModal();
        this.cargarproveedores();

      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al guardar proveedor');
      }
    });
  }

  // ======================
  // ACTUALIZAR
  // ======================
  actualizarProveedor(): void {

    if (this.editarproveedorForm.invalid || !this.proveedorEditandoId) return;

    this.cargando = true;

    const payload = {
      s_nombre_empresa: this.editarproveedorForm.value.nombre,
      s_contacto: this.editarproveedorForm.value.contacto,
      s_email: this.editarproveedorForm.value.email,
      n_telefono: this.editarproveedorForm.value.telefono,
      active: 1
    };

    this.proveedoresService.actualizarProveedor(this.proveedorEditandoId, payload)
      .subscribe({
        next: (resp: any) => {

          this.cargando = false;
          this.mostrarToast(resp.message || 'Proveedor actualizado');
          this.cerrarModalEditar();
          this.cargarproveedores();

        },
        error: () => {
          this.cargando = false;
          this.mostrarToast('Error al actualizar proveedor');
        }
      });
  }

  // ======================
  // ELIMINAR
  // ======================
  confirmarEliminarProveedor(id: number, nombre: string): void {
    this.proveedorEliminarId = id;
    this.proveedorEliminarNombre = nombre;

    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );

    modal.show();
  }

  confirmarEliminar(): void {
    if (!this.proveedorEliminarId) return;
    this.eliminarProveedor(this.proveedorEliminarId);
    this.cerrarModalEliminar();
  }

  eliminarProveedor(id: number): void {

    this.cargando = true;

    this.proveedoresService.eliminaProveedor(id, { active: 0 })
      .subscribe({
        next: (resp: any) => {

          this.cargando = false;
          this.mostrarToast(resp.message || 'Proveedor desactivado');
          this.cargarproveedores();

        },
        error: () => {
          this.cargando = false;
          this.mostrarToast('Error al desactivar proveedor');
        }
      });
  }

  // ======================
  // MODALES
  // ======================
  abrirModalEditar(
    id: number,
    nombre: string,
    contacto: string,
    email: string,
    telefono: string
  ): void {

    this.proveedorEditandoId = id;

    this.editarproveedorForm.patchValue({
      nombre,
      contacto,
      email,
      telefono
    });

    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarProveedorModal')
    );

    modal.show();
  }

  cerrarModal(): void {
    const modal = document.getElementById('proveedorModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }

  cerrarModalEditar(): void {
    const modal = document.getElementById('editarProveedorModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }

  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();

    this.proveedorEliminarId = null;
    this.proveedorEliminarNombre = '';
  }

  // ======================
  // TOAST
  // ======================
  mostrarToast(mensaje: string): void {

    this.toasts.push(mensaje);

    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }

  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }

}
