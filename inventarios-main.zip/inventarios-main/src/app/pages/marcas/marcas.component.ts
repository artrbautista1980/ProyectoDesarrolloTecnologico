import { Component, OnInit, AfterViewInit } from '@angular/core';
import { MarcasService } from 'src/app/services/marcas.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-marcas',
  templateUrl: './marcas.component.html',
  styleUrls: ['./marcas.component.scss']
})
export class MarcasComponent implements OnInit, AfterViewInit {

  marcaForm!: FormGroup;
  marcas: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarmarcaForm!: FormGroup;
  marcaEditandoId: number | null = null;
  marcaEliminarId: number | null = null;
  marcaEliminarNombre: string = '';

  constructor(
    private marcasService: MarcasService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.marcaForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarmarcaForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarMarcas();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#marcasTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#marcasTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#marcasTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarMarca(id, nombre);
  });
  
  }

  // ======================
  // CARGAR marcas
  // ======================
  cargarMarcas(): void {
    this.marcasService.getMarcas().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Marca guardada correctamente');
    
    
        this.marcas = resp.data.marcas;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.marcas.forEach(e => {
      this.dataTable.row.add([
        e.id_marca,
        e.s_marca,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_marca}"
            data-nombre="${e.s_marca}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_marca}"
            data-nombre="${e.s_marca}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR EMPRESA
  // ======================
  guardarMarca(): void {
    if (this.marcaForm.invalid) {
      this.marcaForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_marca: this.marcaForm.value.nombre,
      active: true
    };

    this.marcasService.crearMarca(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Empresa guardada correctamente');

        // 🔄 recargar lista
        this.cargarMarcas();

        this.marcaForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarMarca(): void {
    if (this.editarmarcaForm.invalid || !this.marcaEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_marca: this.editarmarcaForm.value.nombre,
      active: 1
    };
  
    this.marcasService.actualizarMarca(this.marcaEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Marca actualizada');
  
        this.cargarMarcas();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar empresa');
      }
    });
  }
  confirmarEliminarMarca(id: number, nombre: string): void {
    this.marcaEliminarId = id;
    this.marcaEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.marcaEliminarId) return;
  
    this.eliminarEmpresa(this.marcaEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarEmpresa(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.marcasService.eliminaMarca(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empresa desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarMarcas();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empresa');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('marcaModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarMarcaModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.marcaEliminarId = null;
    this.marcaEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.marcaEditandoId = id;
  
    this.editarmarcaForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarMarcaModal')
    );
  
    modal.show();
  }
  
}
