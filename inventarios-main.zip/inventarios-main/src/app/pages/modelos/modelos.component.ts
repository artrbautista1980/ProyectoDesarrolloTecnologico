import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ModelosService } from 'src/app/services/modelos.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-modelos',
  templateUrl: './modelos.component.html',
  styleUrls: ['./modelos.component.scss']
})
export class ModelosComponent implements OnInit, AfterViewInit {

  modeloForm!: FormGroup;
  modelos: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarmodeloForm!: FormGroup;
  modeloEditandoId: number | null = null;
  modeloEliminarId: number | null = null;
  modeloEliminarNombre: string = '';

  constructor(
    private modelosService: ModelosService,
    private fb: FormBuilder
  ) {}

  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.modeloForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarmodeloForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarmodelos();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    this.dataTable = $('#modelosTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#modelosTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#modelosTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarMarca(id, nombre);
  });
  
  }

  // ======================
  // CARGAR modelos
  // ======================
  cargarmodelos(): void {
    this.modelosService.getModelos().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Modelo guardada correctamente');
    
    
        this.modelos = resp.data.modelos;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.modelos.forEach(e => {
      this.dataTable.row.add([
        e.id_modelo,
        e.s_nombre_modelo,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_modelo}"
            data-nombre="${e.s_nombre_modelo}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_modelo}"
            data-nombre="${e.s_nombre_modelo}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR EMPRESA
  // ======================
  guardarModelo(): void {
    if (this.modeloForm.invalid) {
      this.modeloForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_modelo: this.modeloForm.value.nombre,
      active: true
    };

    this.modelosService.crearModelo(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Modelo guardada correctamente');

        // 🔄 recargar lista
        this.cargarmodelos();

        this.modeloForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarModelo(): void {
    if (this.editarmodeloForm.invalid || !this.modeloEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_nombre_modelo: this.editarmodeloForm.value.nombre,
      active: 1
    };
  
    this.modelosService.actualizarModelo(this.modeloEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Modelo actualizada');
  
        this.cargarmodelos();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar modelo');
      }
    });
  }
  confirmarEliminarMarca(id: number, nombre: string): void {
    this.modeloEliminarId = id;
    this.modeloEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.modeloEliminarId) return;
  
    this.eliminarModelo(this.modeloEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarModelo(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.modelosService.eliminaModelo(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'Empresa desactivada');
  
        // 🔄 Refrescar tabla
        this.cargarmodelos();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar empresa');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('modeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarModeloModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.modeloEliminarId = null;
    this.modeloEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.modeloEditandoId = id;
  
    this.editarmodeloForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarModeloModal')
    );
  
    modal.show();
  }
  
}
