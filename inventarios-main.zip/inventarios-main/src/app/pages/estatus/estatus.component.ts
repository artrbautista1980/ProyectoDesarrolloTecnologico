import { Component, OnInit, AfterViewInit,OnDestroy  } from '@angular/core';
import { EstatusService } from 'src/app/services/estatus.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
   selector: 'app-estatus',
  templateUrl: './estatus.component.html',
  styleUrls: ['./estatus.component.scss']
})
export class EstatusComponent implements OnInit, AfterViewInit,OnDestroy  {

  estatusForm!: FormGroup;
  estatus: any[] = [];
  cargando = false;
  toastMessage = '';
  toastInstance: any;
  dataTable: any;
  toasts: string[] = [];
  editarEstatusForm!: FormGroup;
  estatusEditandoId: number | null = null;
  estatusEliminarId: number | null = null;
  estatusEliminarNombre: string = '';

  constructor(
    private estatusService: EstatusService,
    private fb: FormBuilder
  ) {}

  
  // ======================
  // INIT
  // ======================
  ngOnInit(): void {
    this.estatusForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    this.editarEstatusForm = this.fb.group({
      nombre: ['', Validators.required]
    });
    

    this.cargarEstatus();
  }

  // ======================
  // INICIALIZAR DATATABLE SOLO UNA VEZ
  // ======================
  ngAfterViewInit(): void {
    if ($.fn.DataTable.isDataTable('#estatusTable')) {
  $('#estatusTable').DataTable().destroy();
    }
    this.dataTable = $('#estatusTable').DataTable({
      responsive: true,
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
      }
    });
     // Inicializar Toast Bootstrap
  const toastEl = document.getElementById('toastSuccess');
  if (toastEl) {
    this.toastInstance = new (window as any).bootstrap.Toast(toastEl, {
      delay: 3500
    });
  }

  $('#estatusTable tbody').on('click', '.btn-editar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.abrirModalEditar(id, nombre);
  });
  $('#estatusTable tbody').on('click', '.btn-eliminar', (event: any) => {
    const button = $(event.currentTarget);
    const id = button.data('id');
    const nombre = button.data('nombre');
  
    this.confirmarEliminarEstatus(id, nombre);
  });
  
  }
  ngOnDestroy(): void {
  if (this.dataTable) {
    this.dataTable.destroy(true);
    this.dataTable = null;
  }
  }
  // ======================
  // CARGAR ESTATUS
  // ======================
  cargarEstatus(): void {
    this.estatusService.getallEstatus().subscribe({
      next: (resp: any) => {
        this.cargando = false;

    // 🟢 Mostrar mensaje del backend
    this.mostrarToast(resp.message || 'Estatus guardada correctamente');
    
    
        this.estatus = resp.data.estatus;

        // 🔥 ACTUALIZAR DATATABLE CORRECTAMENTE
        this.refrescarDataTable();
      },
      error: (err) => console.error(err)
    });
  }

  // ======================
  // REFRESCAR DATATABLE
  // ======================
  refrescarDataTable(): void {
    if (!this.dataTable) return;

    // Limpia filas actuales
    this.dataTable.clear();

    // Agrega filas nuevas
    this.estatus.forEach(e => {
      this.dataTable.row.add([
        e.id_estatus,
        e.s_nombre_estatus,
        (e.active === true || e.active === 1 || e.active === '1')
          ? '<span class="badge bg-success">Activo</span>'
          : '<span class="badge bg-danger">Inactivo</span>',
        `
          <button class="btn btn-sm btn-warning me-2 btn-editar"
            data-id="${e.id_estatus}"
            data-nombre="${e.s_nombre_estatus}">
            <i class="fas fa-edit"></i>
          </button>
      
          <button class="btn btn-sm btn-danger btn-eliminar"
            data-id="${e.id_estatus}"
            data-nombre="${e.s_nombre_estatus}">
            <i class="fas fa-trash"></i>
          </button>
        `
      ]);
      
    });

    // Dibuja cambios
    this.dataTable.draw();
  }

  // ======================
  // GUARDAR ESTATUS
  // ======================
  guardarEstatus(): void {
    if (this.estatusForm.invalid) {
      this.estatusForm.markAllAsTouched();
      return;
    }

    this.cargando = true;

    const payload = {
      s_nombre_estatus: this.estatusForm.value.nombre,
      active: true
    };

    this.estatusService.crearEstatus(payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;

        // 🟢 Mostrar mensaje del backend
        this.mostrarToast(resp.message || 'Estatus guardada correctamente');

        // 🔄 recargar lista
        this.cargarEstatus();

        this.estatusForm.reset();
        this.cerrarModal();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
      }
    });
  }
  actualizarEstatus(): void {
    if (this.editarEstatusForm.invalid || !this.estatusEditandoId) return;
  
    this.cargando = true;
  
    const payload = {
      s_nombre_estatus: this.editarEstatusForm.value.nombre,
      active: 1
    };
  
    this.estatusService.actualizarEstatus(this.estatusEditandoId, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        this.mostrarToast(resp.message || 'Estatus actualizado');
  
        this.cargarEstatus();
  
        this.cerrarModalEditar();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al actualizar Estatus');
      }
    });
  }
  confirmarEliminarEstatus(id: number, nombre: string): void {
    this.estatusEliminarId = id;
    this.estatusEliminarNombre = nombre;
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('confirmarEliminarModal')
    );
  
    modal.show();
  }
  confirmarEliminar(): void {
    if (!this.estatusEliminarId) return;
  
    this.eliminarEstatus(this.estatusEliminarId);
    this.cerrarModalEliminar();
  }
  
  eliminarEstatus(id: number): void {
    this.cargando = true;
    const payload = {
      active: 0
    };
  
    this.estatusService.eliminaEstatus(id, payload).subscribe({
      next: (resp: any) => {
        this.cargando = false;
  
        // 🔔 Toast de confirmación
        this.mostrarToast(resp.message || 'estatus desactivado');
  
        // 🔄 Refrescar tabla
        this.cargarEstatus();
      },
      error: () => {
        this.cargando = false;
        this.mostrarToast('Error al desactivar estatus');
      }
    });
  }
  
  // ======================
  // CERRAR MODAL
  // ======================
  cerrarModal(): void {
    const modal = document.getElementById('estatusModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEditar(): void {
    const modal = document.getElementById('editarEstatusModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  }
  cerrarModalEliminar(): void {
    const modal = document.getElementById('confirmarEliminarModal');
    const instance = (window as any).bootstrap.Modal.getInstance(modal);
    instance?.hide();
  
    this.estatusEliminarId = null;
    this.estatusEliminarNombre = '';
  }
  
  
  mostrarToast(mensaje: string): void {
    this.toasts.push(mensaje);
  
    // Auto cerrar después de 4 segundos
    setTimeout(() => {
      this.toasts.shift();
    }, 4000);
  }
  cerrarToast(mensaje: string): void {
    this.toasts = this.toasts.filter(t => t !== mensaje);
  }
  abrirModalEditar(id: number, nombre: string): void {
    this.estatusEditandoId = id;
  
    this.editarEstatusForm.patchValue({
      nombre
    });
  
    const modal = new (window as any).bootstrap.Modal(
      document.getElementById('editarEstatusModal')
    );
  
    modal.show();
  }
  
}
