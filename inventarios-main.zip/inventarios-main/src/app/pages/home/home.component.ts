import { Component, OnInit } from '@angular/core';
import { AnyARecord } from 'dns';
import { ActivatedRoute,Router } from '@angular/router'; 
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  menuCollapsed = false;

  toggleMenu(): void {
    this.menuCollapsed = !this.menuCollapsed;
  }
  data : any ={};
  id_contacto : any;


 

  constructor(
 
              private route: ActivatedRoute,
              private AuthService :AuthService,
              private router: Router
              ) { }
              
  ngOnInit(): void {
  /*   console.log(this.vCardString);
    this.vCard.name?.firstNames  ;
    console.log("EL ID A CONSULTAR ES : "+this.route.snapshot.paramMap.get("id"));
    this.id_contacto = this.route.snapshot.paramMap.get("id");
    this.getById(this.id_contacto); 
 */
  }
  logout(): void {
    this.AuthService.logout().subscribe({
      next: () => {
        // Limpia sesión local
        localStorage.clear();
        sessionStorage.clear();
  
        // Redirige al login
        window.location.href = '/';
      },
      error: () => {
        // Aun con error, cerrar sesión local
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = '/';
      }
    });
  }
  
  removeAccents(str : any) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } 


  getById(id_contacto : any){
  
  }
  
}
