import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BitacoraService } from 'src/app/services/bitacora.service';
import { skip } from 'rxjs/operators';
import { forkJoin } from 'rxjs';

// 🔹 Servicios
import { EmpresasService } from 'src/app/services/empresas.service';
import { EstatusService } from 'src/app/services/estatus.service';
import { ProveedoresService } from 'src/app/services/proveedores.service';
import { MarcasService } from 'src/app/services/marcas.service';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { ModelosService } from 'src/app/services/modelos.service';

// 🔹 Excel
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-bitacora',
  templateUrl: './bitacora.component.html',
  styleUrls: ['./bitacora.component.scss']
})
export class BitacoraComponent implements OnInit {

  bitacoras: any[] = [];
  bitacorasFiltradas: any[] = [];
  cargando: boolean = false;

  filtrosForm!: FormGroup;

  // 🔹 MAPS
  empleadosMap: any = {};
  empresasMap: any = {};
  estatusMap: any = {};
  proveedoresMap: any = {};
  marcasMap: any = {};
  modelosMap: any = {};

  // 🔹 PAGINACIÓN
  paginaActual: number = 1;
  registrosPorPagina: number = 10;

  constructor(
    private fb: FormBuilder,
    private bitacoraService: BitacoraService,
    private empleadosService: EmpleadosService,
    private empresasService: EmpresasService,
    private estatusService: EstatusService,
    private proveedorService: ProveedoresService,
    private marcasService: MarcasService,
    private modelosService: ModelosService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.cargarTodo();
    this.detectarCambiosFiltros();
  }

  // 🔹 FORM
  initForm(): void {
    this.filtrosForm = this.fb.group({
      empleado: [''],
      empresa: [''],
      marca: [''],
      modelo: [''],
      fechaInicio: [''],
      fechaFin: ['']
    });
  }

  detectarCambiosFiltros(): void {
    this.filtrosForm.valueChanges
      .pipe(skip(1))
      .subscribe(() => this.aplicarFiltros());
  }

  // 🔥 CARGAR TODO
  cargarTodo(): void {

    this.cargando = true;

    forkJoin({
      catalogos: forkJoin({
        empresas: this.empresasService.getEmpresas(),
        estatus: this.estatusService.getallEstatus(),
        proveedores: this.proveedorService.getProveedores(),
        empleados: this.empleadosService.getEmpleados(),
        marcas: this.marcasService.getMarcas(),
        modelos: this.modelosService.getModelos(),
      }),
      bitacoras: this.bitacoraService.getBitacoras()
    }).subscribe({
      next: (resp: any) => {

        const c = resp.catalogos;

        // 🔥 MAPS
        c.empleados.data.empleados.forEach((e: any) => {
          this.empleadosMap[e.id_empleado] = `${e.s_nombre} ${e.s_apaterno} ${e.s_amaterno}`;
        });

        c.empresas.data.empresas.forEach((e: any) => {
          this.empresasMap[e.id_empresa] = e.s_nombre_empresa;
        });

        c.estatus.data.estatus.forEach((e: any) => {
          this.estatusMap[e.id_estatus] = e.s_nombre_estatus;
        });

        c.proveedores.data.proveedores.forEach((e: any) => {
          this.proveedoresMap[e.id_proveedor] = e.s_nombre_empresa;
        });

        c.marcas.data.marcas.forEach((e: any) => {
          this.marcasMap[e.id_marca] = e.s_marca;
        });

        c.modelos.data.modelos.forEach((e: any) => {
          this.modelosMap[e.id_modelo] = e.s_nombre_modelo;
        });

        // 🔥 BITÁCORA TRANSFORMADA
        const data = resp.bitacoras.data.bitacora;

        this.bitacoras = data.map((item: any) => ({
          ...item,
          empleado_nombre: this.empleadosMap[item.id_empleado],
          empresa_nombre: this.empresasMap[item.id_empresa],
          estatus_nombre: this.estatusMap[item.id_estatus],
          marca_nombre: this.marcasMap[item.id_marca],
          modelo_nombre: this.modelosMap[item.id_modelo],
          proveedor_nombre: this.proveedoresMap[item.id_proveedor],
        }));

        this.bitacorasFiltradas = [...this.bitacoras];

        this.cargando = false;
      },
      error: (err) => {
        console.error(err);
        this.cargando = false;
      }
    });
  }

  // 🔥 FILTROS
  aplicarFiltros(): void {

    const { empleado, empresa, marca, modelo, fechaInicio, fechaFin } = this.filtrosForm.value;

    this.bitacorasFiltradas = this.bitacoras.filter(item => {

      const empleadoVal = (item.empleado_nombre || '').toLowerCase();
      const empresaVal = (item.empresa_nombre || '').toLowerCase();
      const marcaVal = (item.marca_nombre || '').toLowerCase();
      const modeloVal = (item.modelo_nombre || '').toLowerCase();
      const fecha = new Date(item.fecha_actualizacion);

      const coincideEmpleado = empleado ? empleadoVal.includes(empleado.toLowerCase()) : true;
      const coincideEmpresa = empresa ? empresaVal.includes(empresa.toLowerCase()) : true;
      const coincideMarca = marca ? marcaVal.includes(marca.toLowerCase()) : true;
      const coincideModelo = modelo ? modeloVal.includes(modelo.toLowerCase()) : true;
      const coincideFechaInicio = fechaInicio ? fecha >= new Date(fechaInicio) : true;
      const coincideFechaFin = fechaFin ? fecha <= new Date(fechaFin + 'T23:59:59') : true;

      return coincideEmpleado && coincideEmpresa && coincideMarca && coincideModelo && coincideFechaInicio && coincideFechaFin;
    });

    this.paginaActual = 1;
  }

  limpiarFiltros(): void {
    this.filtrosForm.reset();
    this.bitacorasFiltradas = this.bitacoras;
    this.paginaActual = 1;
  }

  // 🔥 PAGINACIÓN
  get bitacorasPaginadas(): any[] {
    const inicio = (this.paginaActual - 1) * this.registrosPorPagina;
    return this.bitacorasFiltradas.slice(inicio, inicio + this.registrosPorPagina);
  }

  get totalPaginas(): number {
    return Math.ceil(this.bitacorasFiltradas.length / this.registrosPorPagina);
  }

  cambiarPagina(pagina: number): void {
    if (pagina >= 1 && pagina <= this.totalPaginas) {
      this.paginaActual = pagina;
    }
  }

  // 🔥 EXPORTAR EXCEL
  exportarExcel(): void {

    const data = this.bitacorasFiltradas.map(item => ({
      Empleado: item.empleado_nombre,
      Empresa: item.empresa_nombre,
      Estatus: item.estatus_nombre,
      Marca: item.marca_nombre,
      Modelo: item.modelo_nombre,
      Proveedor: item.proveedor_nombre,
      Serie: item.s_serie,
      Fecha: item.fecha_actualizacion
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = {
      Sheets: { 'Bitacora': worksheet },
      SheetNames: ['Bitacora']
    };

    const excelBuffer = XLSX.write(workbook, {
      bookType: 'xlsx',
      type: 'array'
    });

    const blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
    FileSaver.saveAs(blob, `Bitacora_${new Date().getTime()}.xlsx`);
  }
}