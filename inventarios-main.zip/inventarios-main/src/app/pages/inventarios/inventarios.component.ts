import { Component, OnInit, AfterViewInit,ViewChild, ElementRef  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin } from 'rxjs';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { EmpresasService } from 'src/app/services/empresas.service';
import { EstatusService } from 'src/app/services/estatus.service';
import { ProveedoresService } from 'src/app/services/proveedores.service';
import { TiposEquiposService } from 'src/app/services/tipos-equipos.service';
import { MarcasService } from 'src/app/services/marcas.service';
import { SoftwareService } from 'src/app/services/software.service';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { ModelosService } from 'src/app/services/modelos.service';
import { InventariosService } from 'src/app/services/inventarios.service';
import { BitacoraService } from 'src/app/services/bitacora.service';
import { FacturasService } from 'src/app/services/facturas.service';

declare var $: any;


@Component({
  selector: 'app-inventarios',
  templateUrl: './inventarios.component.html',
  styleUrls: ['./inventarios.component.scss']
})
export class InventariosComponent implements OnInit, AfterViewInit {
  @ViewChild('pdfContainer') pdfContainer!: ElementRef;
  pdfData: any;
  inventarioForm!: FormGroup;
  cargando = false;
  modoEdicion: boolean = false;
  idEditando: number | null = null;
  empresas: any[] = [];
  estatus: any[] = [];
  proveedores: any[] = [];
  tiposEquipos: any[] = [];
  marcas: any[] =[];
  modelos: any[] =[];
  softwares: any[] = [];
  empleados: any[] = [];
  inventarios: any[] = [];
  dataTable: any;
  errorArchivo: string = '';
  archivoFactura: File | null = null;
today: string = new Date().toLocaleDateString('es-MX', {
  year: 'numeric',
  month: 'long',
  day: 'numeric'
});
  constructor(
    private fb: FormBuilder,
    private empresasService: EmpresasService,
    private estatusService: EstatusService,
    private proveedorService: ProveedoresService,
    private tiposEquiposService: TiposEquiposService,
    private softwareService: SoftwareService,
    private empleadosService: EmpleadosService,
    private inventariosService: InventariosService,
    private marcasService:MarcasService,
    private modelosService:ModelosService,
    private bitacoraService:BitacoraService,
    private facturasService: FacturasService
  ) {}

  ngOnInit(): void {
    this.inicializarFormulario();
    this.cargarCatalogos();
  }
 ngAfterViewInit(): void {

  this.dataTable = $('#inventariosTable').DataTable({
  responsive: true,
  dom: '<"top d-flex justify-content-end align-items-center gap-2"Bf>rtip',
   drawCallback: () => {

    const api = this.dataTable;

    $('#inventariosTable tbody tr').each((index:any, row:any) => {

      const data = api.row(row).data();

      if (!data) return;

      const active = data[data.length - 1];

      if (Number(active) === 0) {
        $(row).addClass('fila-inactiva');
      } else {
        $(row).removeClass('fila-inactiva');
      }

    });

  },
  buttons: [
    {
      extend: 'excelHtml5',
      text: `
      <span style="display:flex; align-items:center; gap:6px;">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
             fill="white" viewBox="0 0 16 16">
          <path d="M5.884 6.68L4.293 4.5H2.5l2.47 3.428L2.5 11.5h1.793l1.591-2.18L7.475 11.5H9.27L6.8 7.928 9.27 4.5H7.475L5.884 6.68z"/>
          <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5z"/>
        </svg>
        <strong>XLS</strong>
      </span>
    `,
      title: 'Inventario_Equipos',
      className: 'btn-excel-icon',
      columnDefs: [
        {
          targets: -1,
          visible: false
        }
      ],
      exportOptions: {
        columns: [0,1,2,3,4,5,6,7,8,9],
        modifier: {
          search: 'applied',
          order: 'applied',
          page: 'all'
        }
      }
    }
  ],
  language: {
    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
  }
});

  // 🔴 EVENTO CLICK PARA BOTÓN PDF
  $('#inventariosTable tbody').on('click', '.btn-pdf', (event: any) => {

    const id = $(event.currentTarget).data('id');

    const inventario = this.inventarios.find(i => i.id_inventario == id);

    if (inventario) {
      this.generarPDF(inventario);
    }

  });
  // 🟢 EDITAR
$('#inventariosTable tbody').on('click', '.btn-editar', (event: any) => {

  const id = $(event.currentTarget).data('id');
  const inventario = this.inventarios.find(i => i.id_inventario == id);

  if (inventario) {
    this.cargarParaEditar(inventario);
  }

});

// 🔴 ELIMINAR
$('#inventariosTable tbody').on('click', '.btn-eliminar', (event: any) => {

  const id = $(event.currentTarget).data('id');

  if (confirm('¿Deseas eliminar este inventario?')) {
    this.eliminarInventario(id);
  }

});

}
obtenerNombreEmpresa(id: number): string {
  if (!this.empresas.length) return '...';
  const e = this.empresas.find(x => x.id_empresa === id);
  return e ? e.s_nombre_empresa : 'N/A';
}

obtenerNombreEmpleado(id: number): string {
  const emp = this.empleados.find(x => x.id_empleado === id);
  return emp ? `${emp.s_nombre} ${emp.s_apaterno}` : '';
}

obtenerNombreEstatus(id: number): string {
  const es = this.estatus.find(x => x.id_estatus === id);
  return es ? es.s_nombre_estatus : '';
}
obtenerTipoEquipo(id: number): string {
  const es = this.tiposEquipos.find(x => x.id_tipo_equipo === id);
  return es ? es.s_nombre_tipo_equipo : '';
}
obtenernombreMarca(id: number): string {
  const es = this.marcas.find(x => x.id_marca === id);
  return es ? es.s_marca : '';
}
obtenerNoEmpleado(id: number): string {
  const emp = this.empleados.find(x => x.id_empleado === id);
  return emp ? `${emp.n_noempleado}` : '';
}
obtenerNombreModelo(id: number): string {
  const emp = this.modelos.find(x => x.id_modelo === id);
  return emp ? `${emp.s_nombre_modelo}` : '';
}
refrescarDataTable(): void {

  if (!this.dataTable) return;

  this.dataTable.clear();

  this.inventarios.forEach(inv => {

    this.dataTable.row.add([
      inv.id_inventario,
      this.obtenerNombreEmpresa(inv.id_empresa),
      this.obtenerNombreEmpleado(inv.id_empleado),
      this.obtenerNombreEstatus(inv.id_estatus),
      inv.s_serie,
      this.obtenerNombreModelo(inv.id_modelo),
      this.obtenernombreMarca(inv.id_marca),
      inv.s_activo_fijo_sap || '-',
      inv.s_ubicacion_fisica,
      inv.s_accesorio || '-',

      `
      <div class="d-flex gap-1">
        <button class="btn btn-primary btn-sm btn-editar"
                data-id="${inv.id_inventario}">
          Editar
        </button>

        <button class="btn btn-danger btn-sm btn-eliminar"
                data-id="${inv.id_inventario}">
          Eliminar
        </button>

        <button class="btn btn-secondary btn-sm btn-pdf"
                data-id="${inv.id_inventario}">
          PDF
        </button>
      </div>
      `,

      inv.active
    ]);

  });

  this.dataTable.draw(false);

 

}
  cargarInventarios(): void {
  this.inventariosService.getInventarios().subscribe({
    next: (resp: any) => {
      this.inventarios = resp.data.inventarios;
      this.refrescarDataTable();
    },
    error: (err) => console.error(err)
  });
}
  // ==============================
  // FORMULARIO
  // ==============================
 inicializarFormulario(): void {
  this.inventarioForm = this.fb.group({
    id_empresa: ['', Validators.required],
    id_estatus: ['', Validators.required],
    id_proveedor: ['', Validators.required],
    id_tipo_equipo: ['', Validators.required],
    id_software: ['', Validators.required],
    id_empleado: ['', Validators.required],
    
    // 🔥 NUEVOS CAMPOS
    s_ubicacion_fisica: ['', Validators.required],
    s_activo_fijo_sap: [''],
    s_accesorio: [''],
    s_serie: ['', Validators.required],
    id_modelo: ['', Validators.required],
    id_marca: ['', Validators.required],

    s_factura_pdf: [null]
  });
}
cargarParaEditar(inventario: any): void {

  this.modoEdicion = true;
  this.idEditando = inventario.id_inventario;

  this.inventarioForm.patchValue({
    id_empresa: inventario.id_empresa,
    id_estatus: inventario.id_estatus,
    id_proveedor: inventario.id_proveedor,
    id_tipo_equipo: inventario.id_tipo_equipo,
    id_software: inventario.id_software_instalado,
    id_empleado: inventario.id_empleado,
    s_ubicacion_fisica: inventario.s_ubicacion_fisica,
    s_activo_fijo_sap: inventario.s_activo_fijo_sap,
    s_accesorio: inventario.s_accesorio,
    s_serie: inventario.s_serie,
    id_modelo: inventario.id_modelo,
    id_marca: inventario.id_marca
  });

  this.inventarioForm.updateValueAndValidity();
  this.inventarioForm.markAsDirty();

  this.abrirModaleditar();
}
eliminarInventario(id: number): void {
  const payload = {
      active: 0
    };
  this.inventariosService.eliminaInventario(id,payload).subscribe({
    next: () => {
      this.cargarInventarios();
    },
    error: (err) => console.error(err)
  });

}

  // ==============================
  // CARGAR CATÁLOGOS
  // ==============================
cargarCatalogos(): void {
  forkJoin({
    empresas: this.empresasService.getEmpresas(),
    estatus: this.estatusService.getallEstatus(),
    proveedores: this.proveedorService.getProveedores(),
    tipos: this.tiposEquiposService.getTipos(),
    software: this.softwareService.getSoftware_(),
    empleados: this.empleadosService.getEmpleados(),
    marcas: this.marcasService.getMarcas(),
    modelos: this.modelosService.getModelos(),
  }).subscribe({
    next: (resp: any) => {

      this.empresas = resp.empresas.data.empresas;
      this.estatus = resp.estatus.data.estatus;
      this.proveedores = resp.proveedores.data.proveedores;
      this.tiposEquipos = resp.tipos.data.tiposequipos;
      this.softwares = resp.software.data.softwareinstalados;
      this.empleados = resp.empleados.data.empleados;
      this.marcas = resp.marcas.data.marcas;
      this.modelos = resp.modelos.data.modelos;

      // 🔥 AQUÍ cargas inventarios
      this.cargarInventarios();

    },
    error: (err) => console.error(err)
  });
}
  // ==============================
  // CAPTURAR ARCHIVO
  // ==============================
onFileSelected(event: any): void {
  const file = event.target.files[0];

  this.errorArchivo = '';

  if (!file) return;

  const maxSize = 1024 * 1024;

  if (file.type !== 'application/pdf') {
    this.errorArchivo = 'Solo se permiten archivos PDF';
    this.archivoFactura = null;
    event.target.value = '';
    return;
  }

  if (file.size > maxSize) {
    this.errorArchivo = 'El archivo no debe superar 1 MB';
    this.archivoFactura = null;
    event.target.value = '';
    return;
  }

  this.archivoFactura = file;
}
  convertirABase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.readAsDataURL(file);

    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
}

  // ==============================
  // GUARDAR INVENTARIO
  // ==============================
guardarInventario(): void {

  if (this.inventarioForm.invalid) {
    this.inventarioForm.markAllAsTouched();
    return;
  }

  this.cargando = true;

  const payload: any = {
    id_empresa: this.inventarioForm.value.id_empresa,
    id_estatus: this.inventarioForm.value.id_estatus,
    id_empleado: this.inventarioForm.value.id_empleado,
    id_proveedor: this.inventarioForm.value.id_proveedor,
    id_tipo_equipo: this.inventarioForm.value.id_tipo_equipo,
    id_marca: this.inventarioForm.value.id_marca,
    id_modelo: this.inventarioForm.value.id_modelo,
    s_ubicacion_fisica: this.inventarioForm.value.s_ubicacion_fisica,
    s_activo_fijo_sap: this.inventarioForm.value.s_activo_fijo_sap,
    s_accesorio: this.inventarioForm.value.s_accesorio,
    s_serie: this.inventarioForm.value.s_serie,
    id_software_instalado: this.inventarioForm.value.id_software,
    active: 1
  };

  let request;

  // =====================================
  // ✏️ EDITAR
  // =====================================
  if (this.modoEdicion) {

    request = this.inventariosService.actualizarInvenario(
      this.idEditando!,
      payload
    );

  } 
  // =====================================
  // 🆕 CREAR
  // =====================================
  else {

    const formData = new FormData();

    Object.keys(payload).forEach(key => {
      formData.append(key, payload[key]);
    });

    request = this.inventariosService.crearInventario(formData);
  }

  request.subscribe({
    next: async (resp: any) => {

      const idInventario = resp?.id || resp?.data?.id_inventario;

      console.log('RESPUESTA INVENTARIO:', resp);
      console.log('ID INVENTARIO:', idInventario);

      // =========================================
      // 🧾 GUARDAR FACTURA Y LIGARLA
      // =========================================
      if (this.archivoFactura && idInventario) {

        try {

          let base64 = await this.convertirABase64(this.archivoFactura);

          if (base64.includes('base64,')) {
            base64 = base64.split('base64,')[1];
          }

          const facturaPayload: any = {
            d_fecha_facturacion: new Date().toISOString().slice(0, 19).replace('T', ' '),
            id_proveedor: parseInt(payload.id_proveedor),
            n_numero_orden: 0,
            s_folio_factura: 'N/A',
            id_inventario: idInventario,
            s_factura_pdf: base64
          };

          console.log('PAYLOAD FACTURA:', facturaPayload);

          this.facturasService.crearfacturas(facturaPayload).subscribe({
            next: (resFactura: any) => {

              console.log('Factura guardada:', resFactura);

             const idFactura = resFactura?.id_factura || resFactura?.data?.id_factura;

            if (!idFactura) {
              console.error('No llegó id_factura', resFactura);
              return;
            }

              // 🔥 ACTUALIZAR INVENTARIO CON FACTURA
              const updatePayload = {
                id_factura: idFactura
              };

              this.inventariosService.actualizarInvenario(idInventario, updatePayload)
                .subscribe({
                  next: () => {
                    console.log('Inventario actualizado con factura');
                  },
                  error: (err) => {
                    console.error('Error actualizando inventario', err);
                  }
                });

            },
            error: (err) => {
              console.error('ERROR FACTURA:', err);
            }
          });

        } catch (error) {
          console.error('Error convirtiendo PDF', error);
        }
      }

      // =========================================
      // 📒 BITÁCORA
      // =========================================
      const fechaActual = new Date().toISOString().slice(0, 19).replace('T', ' ');

      const bitacoraPayload: any = {
        id_empleado: payload.id_empleado,
        id_empresa: payload.id_empresa,
        id_estatus: payload.id_estatus,
        id_marca: payload.id_marca,
        id_modelo: payload.id_modelo,
        id_proveedor: payload.id_proveedor,
        s_serie: payload.s_serie,
        fecha_actualizacion: fechaActual
      };

      const formDataBitacora = new FormData();
      Object.keys(bitacoraPayload).forEach(key => {
        formDataBitacora.append(key, bitacoraPayload[key]);
      });

      this.bitacoraService.crearBitacora(formDataBitacora).subscribe({
        next: () => console.log('Bitácora guardada correctamente'),
        error: (err) => console.error('Error en bitácora:', err)
      });

      // =========================================
      // 🔄 RESET UI
      // =========================================
      this.cargando = false;
      this.inventarioForm.reset();
      this.archivoFactura = null;

      this.modoEdicion = false;
      this.idEditando = null;

      this.cerrarModal();
      this.cargarInventarios();
    },

    error: (err) => {
      this.cargando = false;
      console.error('Error al guardar inventario:', err);
    }
  });
}
async generarPDF(inventario: any) {

  this.cargando = true; // 🔥 ACTIVAR LOADING

  this.pdfData = {
    empleado: this.obtenerNombreEmpleado(inventario.id_empleado),
    numeroEmpleado: this.obtenerNoEmpleado(inventario.id_empleado),
    tipo_equipo: this.obtenerTipoEquipo(inventario.id_tipo_equipo),
    s_serie: inventario.s_serie,
    marca: this.obtenernombreMarca(inventario.id_marca),
    modelo: this.obtenerNombreModelo(inventario.id_modelo),
    s_ubicacion_fisica: inventario.s_ubicacion_fisica,
    s_activo_fijo_sap: inventario.s_activo_fijo_sap
  };

  await new Promise(resolve => setTimeout(resolve, 300));

  const element = this.pdfContainer.nativeElement;

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true
  });

  const imgData = canvas.toDataURL('image/png');

  const pdf = new jsPDF('p', 'mm', 'a4');

  const imgWidth = 210;
  const imgHeight = canvas.height * imgWidth / canvas.width;

  pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);

  pdf.save(`Carta_Responsiva_${inventario.s_serie}.pdf`);

  this.cargando = false; // 🔥 DESACTIVAR LOADING
}
abrirModaleditar(): void {

  this.archivoFactura = null;

  const modal = new (window as any).bootstrap.Modal(
    document.getElementById('inventarioModal')
  );
  modal.show();
}
abrirModalNuevo(): void {
  this.modoEdicion = false;
  this.idEditando = null;
  this.inventarioForm.reset();
  this.archivoFactura = null;

  const modal = new (window as any).bootstrap.Modal(
    document.getElementById('inventarioModal')
  );
  modal.show();
}

cerrarModal(): void {
  const modal = (window as any).bootstrap.Modal.getInstance(
    document.getElementById('inventarioModal')
  );
  if (modal) modal.hide();
}

}