import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { EmpresasComponent } from './pages/empresas/empresas/empresas.component';
import { EstatusComponent } from './pages/estatus/estatus.component';
import { MarcasComponent } from './pages/marcas/marcas.component';
import { ModelosComponent } from './pages/modelos/modelos.component';
import { ProveedoresComponent } from './pages/proveedores/proveedores.component';
import { SoftwareComponent } from './pages/software/software.component';
import { TiposEquiposComponent } from './pages/tipos-equipos/tipos-equipos.component';
import { UbicacionesComponent } from './pages/ubicaciones/ubicaciones.component';
import { EmpleadosComponent } from './pages/empleados/empleados.component';
import { InventariosComponent } from './pages/inventarios/inventarios.component';
import { BitacoraComponent } from './pages/bitacora/bitacora.component';
import { FacturasComponent } from './pages/facturas/facturas.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: 'home',
    component: HomeComponent,
    children: [
      { path: '', component: DashboardComponent },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'empresas', component: EmpresasComponent },
      { path: 'estatus', component: EstatusComponent },
      { path: 'marcas', component: MarcasComponent },
      { path: 'modelos', component: ModelosComponent },
      { path: 'proveedores', component: ProveedoresComponent },
      { path: 'software', component: SoftwareComponent },
      { path: 'tipos', component: TiposEquiposComponent },
      { path: 'ubicaciones', component: UbicacionesComponent },
      { path: 'empleados', component: EmpleadosComponent },
      { path: 'inventarios', component: InventariosComponent },
      { path: 'bitacora', component: BitacoraComponent },
      { path: 'facturas', component: FacturasComponent },
      

      // aquí irán más módulos
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
