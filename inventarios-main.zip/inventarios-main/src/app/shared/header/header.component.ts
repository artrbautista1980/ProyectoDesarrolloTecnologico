import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  userName = 'Administrador';
  currentDate = '';

  ngOnInit(): void {
    const today = new Date();

    const options: Intl.DateTimeFormatOptions = {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    };

    this.currentDate = today.toLocaleDateString('es-MX', options);
  }
}
